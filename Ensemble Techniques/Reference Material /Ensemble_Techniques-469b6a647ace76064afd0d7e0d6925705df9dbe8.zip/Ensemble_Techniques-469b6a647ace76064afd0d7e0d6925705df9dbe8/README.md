# Ensemble_Techniques
The project was accomplished by deploying supervised learning and ensemble modelling techniques to build and train a prediction model for a telecom company. This will help them identify the potential customers who have a higher probability to churn. This will enable the company to understand and pinpoints the patterns of customer churn and increase the focus on customer retention strategies.

Skills and Tools : 

EDA, Logistic Regression, Decision Tree, Random Forest, Boosting
