# CNN-Architecture-and-Transfer-Learning
“This project involves 5 sub projects including a CV powered GUI to solve the problem of a botanical research group. Part 1 Image classifier capable of determining a plant's species. Part 2 Detailed analysis on how CNN is a better image classifier over traditional methods Part 3 Curating an image dataset for a brand research company Part 4 Image classifier capable of determining a flower’s species Part 5 Submit your strategy to maintain and support the AIML the model in production” 

Skills and Tools:

Botanical Research, Automobile, Computer Vision, CNN, Transfer Learning, TensorFlow, GUI
