# Advanced-Computer-Vision---Object-Detection-and-recognition
The project involves 4 sub segments. Part 1 Implement an object detection model for highlighting human faces to automate the process of providing information of cast and crew while streaming. Part 2 Curate a training dataset to be used for highlighting human faces. Part 3 Implement a face identification model for a company, which intends to recognize human faces form images. Part 4 Building an automation to impute dynamic bounding boxes to locate cars/vehicles on a video file.

Skills and Tools:

CNN, NN, GUI, Computer Vision, Tensor Flow, Siamese Netoworks, Triplet loss, Object Detection
