# Data-Science-Projects
Projects done by Mohamed Rizwan on various Datasets
1. HR Analytics - Predicting the employees who are likely to leave the company using Decision trees, logistic Regression, KNN
2. Churn Model using Keras - Built a churn model to classify the users who are likely to leave the telecom company
3. House Prices - Used Linear Regression and Predicted the House prices
4. Time Series Forecasting ( SARIMA ) - EDA and Timeseries Forecasting on AirPassengers Dataset
5. Advanced House Prices Prediction - Used Ensemble Techniques for Prediction of House Prices
6. Iris Dataset - EDA and simple Classification Models on iris Dataset
7. Boston Housing Dataset - 
8. Titanic Dataset
9. Wine Quality Dataset
10. Quora Review Classification
11. Ham Spam Classification
12. Loan Prediction - Logistic Regression, DTree,Random Forest, XGBoost for predicting who is the best customer for giving loan
